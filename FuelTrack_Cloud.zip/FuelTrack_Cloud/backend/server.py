#!/usr/bin/env python3
"""
FuelTrack Backend — Flask
يعمل على: Render / Railway / Fly.io / أي استضافة مجانية
قاعدة البيانات: PostgreSQL (على الاستضافة) أو SQLite (محلياً)
"""

import os, hashlib, secrets
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

# ──────────────────────────────────────────────
#  قاعدة البيانات — PostgreSQL أو SQLite تلقائياً
# ──────────────────────────────────────────────
DATABASE_URL = os.environ.get('DATABASE_URL')  # يُعيَّن تلقائياً على Render/Railway

if DATABASE_URL:
    # ── PostgreSQL (على الاستضافة) ──
    import psycopg2
    import psycopg2.extras

    # Render يعطي URL يبدأ بـ postgres:// — نحوّله لـ postgresql://
    if DATABASE_URL.startswith('postgres://'):
        DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)

    def get_db():
        conn = psycopg2.connect(DATABASE_URL)
        conn.autocommit = False
        return conn

    def fetchall(cursor):
        cols = [d[0] for d in cursor.description]
        return [dict(zip(cols, row)) for row in cursor.fetchall()]

    def fetchone(cursor):
        if cursor.description is None:
            return None
        cols = [d[0] for d in cursor.description]
        row  = cursor.fetchone()
        return dict(zip(cols, row)) if row else None

    PH = '%s'   # placeholder لـ PostgreSQL
    DB_TYPE = 'postgres'

else:
    # ── SQLite (تشغيل محلي) ──
    import sqlite3
    DB_PATH = os.path.join(os.path.dirname(__file__), 'fuel.db')

    def get_db():
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn

    def fetchall(cursor):
        return [dict(r) for r in cursor.fetchall()]

    def fetchone(cursor):
        row = cursor.fetchone()
        return dict(row) if row else None

    PH = '?'
    DB_TYPE = 'sqlite'


# ──────────────────────────────────────────────
#  تهيئة الجداول
# ──────────────────────────────────────────────
def init_db():
    conn = get_db()
    c = conn.cursor()

    if DB_TYPE == 'postgres':
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id         SERIAL PRIMARY KEY,
                username   TEXT UNIQUE NOT NULL,
                password   TEXT NOT NULL,
                fullname   TEXT,
                role       TEXT DEFAULT 'user',
                active     INTEGER DEFAULT 1,
                created_at TEXT DEFAULT (to_char(now(),'YYYY-MM-DD HH24:MI:SS'))
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id         SERIAL PRIMARY KEY,
                name       TEXT UNIQUE NOT NULL,
                phone      TEXT,
                location   TEXT,
                created_at TEXT DEFAULT (to_char(now(),'YYYY-MM-DD HH24:MI:SS'))
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id           SERIAL PRIMARY KEY,
                order_number TEXT UNIQUE,
                date         TEXT,
                client       TEXT,
                fuel_type    TEXT,
                qty          REAL,
                price        REAL,
                total        REAL,
                status       TEXT DEFAULT 'معلق',
                notes        TEXT,
                owner_id     INTEGER REFERENCES users(id),
                owner_name   TEXT,
                created_at   TEXT DEFAULT (to_char(now(),'YYYY-MM-DD HH24:MI:SS'))
            )
        """)
    else:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                username   TEXT UNIQUE NOT NULL,
                password   TEXT NOT NULL,
                fullname   TEXT,
                role       TEXT DEFAULT 'user',
                active     INTEGER DEFAULT 1,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS clients (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT UNIQUE NOT NULL,
                phone      TEXT,
                location   TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS orders (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                order_number TEXT UNIQUE,
                date         TEXT,
                client       TEXT,
                fuel_type    TEXT,
                qty          REAL,
                price        REAL,
                total        REAL,
                status       TEXT DEFAULT 'معلق',
                notes        TEXT,
                owner_id     INTEGER REFERENCES users(id),
                owner_name   TEXT,
                created_at   TEXT DEFAULT (datetime('now'))
            );
        """)

    # المستخدمون الافتراضيون
    default_users = [
        ('admin',  hash_pw('admin123'),   'المسؤول الرئيسي', 'admin'),
        ('user1',  hash_pw('user1234'),  'المستخدم الأول',   'user'),
        ('user2',  hash_pw('user1234'),  'المستخدم الثاني',  'user'),
        ('user3',  hash_pw('user1234'),  'المستخدم الثالث',  'user'),
        ('user4',  hash_pw('user1234'),  'المستخدم الرابع',  'user'),
        ('user5',  hash_pw('user1234'),  'المستخدم الخامس',  'user'),
        ('user6',  hash_pw('user1234'),  'المستخدم السادس',  'user'),
        ('user7',  hash_pw('user1234'),  'المستخدم السابع',  'user'),
        ('user8',  hash_pw('user1234'),  'المستخدم الثامن',  'user'),
        ('user9',  hash_pw('user1234'),  'المستخدم التاسع',  'user'),
        ('user10', hash_pw('user1234'),  'المستخدم العاشر',  'user'),
    ]
    for uname, pw, fname, role in default_users:
        try:
            c.execute(
                f"INSERT INTO users (username,password,fullname,role) VALUES ({PH},{PH},{PH},{PH})",
                (uname, pw, fname, role)
            )
        except Exception:
            pass  # موجود مسبقاً

    conn.commit()
    conn.close()
    print(f"[DB] تهيئة قاعدة البيانات ({DB_TYPE}) ✓")


# ──────────────────────────────────────────────
#  مساعدات
# ──────────────────────────────────────────────
def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

# الجلسات في الذاكرة (كافية للاستضافة المجانية)
sessions = {}

def create_session(user_row):
    token = secrets.token_hex(32)
    sessions[token] = {
        'id':       user_row['id'],
        'username': user_row['username'],
        'fullname': user_row['fullname'],
        'role':     user_row['role'],
    }
    return token

def get_session():
    token = request.headers.get('X-Token', '')
    return sessions.get(token), token

def require_auth():
    user, _ = get_session()
    if not user:
        return None, jsonify({'ok': False, 'error': 'غير مصرح'}), 401
    return user, None, None

def require_admin():
    user, err, code = require_auth()
    if err:
        return None, err, code
    if user['role'] != 'admin':
        return None, jsonify({'ok': False, 'error': 'صلاحيات المسؤول مطلوبة'}), 403
    return user, None, None


# ──────────────────────────────────────────────
#  الصفحة الرئيسية — يخدم index.html
# ──────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')


# ──────────────────────────────────────────────
#  API: تسجيل الدخول والخروج
# ──────────────────────────────────────────────
@app.route('/api/login', methods=['POST'])
def login():
    b     = request.get_json() or {}
    uname = b.get('username', '').strip()
    pw    = hash_pw(b.get('password', ''))
    conn  = get_db()
    c     = conn.cursor()
    c.execute(
        f"SELECT * FROM users WHERE username={PH} AND password={PH} AND active=1",
        (uname, pw)
    )
    row = fetchone(c)
    conn.close()
    if not row:
        return jsonify({'ok': False, 'error': 'اسم المستخدم أو كلمة المرور غير صحيحة'}), 401
    token = create_session(row)
    return jsonify({'ok': True, 'token': token, 'user': {
        'id': row['id'], 'username': row['username'],
        'fullname': row['fullname'], 'role': row['role']
    }})

@app.route('/api/logout', methods=['POST'])
def logout():
    _, token = get_session()
    sessions.pop(token, None)
    return jsonify({'ok': True})

@app.route('/api/me')
def me():
    user, err, code = require_auth()
    if err: return err, code
    return jsonify({'ok': True, 'user': user})


# ──────────────────────────────────────────────
#  API: الطلبات
# ──────────────────────────────────────────────
@app.route('/api/orders', methods=['GET'])
def get_orders():
    user, err, code = require_auth()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    if user['role'] == 'admin':
        c.execute("SELECT * FROM orders ORDER BY created_at DESC")
    else:
        c.execute(f"SELECT * FROM orders WHERE owner_id={PH} ORDER BY created_at DESC", (user['id'],))
    rows = fetchall(c)
    conn.close()
    return jsonify({'ok': True, 'orders': rows})

@app.route('/api/orders', methods=['POST'])
def create_order():
    user, err, code = require_auth()
    if err: return err, code
    b    = request.get_json() or {}
    conn = get_db(); c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM orders")
    count = c.fetchone()[0] if DB_TYPE == 'sqlite' else c.fetchone()[0]
    order_num = f"ORD-{1000 + count + 1}"
    today = datetime.now().strftime('%Y/%m/%d')
    qty   = float(b.get('qty', 0))
    price = float(b.get('price', 0))
    total = round(qty * price, 2)
    c.execute(
        f"""INSERT INTO orders (order_number,date,client,fuel_type,qty,price,total,status,notes,owner_id,owner_name)
            VALUES ({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""",
        (order_num, today, b.get('client'), b.get('fuel_type'), qty, price, total,
         b.get('status', 'معلق'), b.get('notes', ''), user['id'], user['fullname'])
    )
    conn.commit()
    if DB_TYPE == 'postgres':
        c.execute("SELECT lastval()")
    else:
        c.execute("SELECT last_insert_rowid()")
    new_id = c.fetchone()[0]
    conn.close()
    return jsonify({'ok': True, 'order_number': order_num, 'id': new_id})

@app.route('/api/orders/<int:oid>', methods=['PUT'])
def update_order(oid):
    user, err, code = require_auth()
    if err: return err, code
    b    = request.get_json() or {}
    conn = get_db(); c = conn.cursor()
    c.execute(f"SELECT * FROM orders WHERE id={PH}", (oid,))
    row = fetchone(c)
    if not row:
        conn.close()
        return jsonify({'ok': False, 'error': 'الطلب غير موجود'}), 404
    if user['role'] != 'admin' and row['owner_id'] != user['id']:
        conn.close()
        return jsonify({'ok': False, 'error': 'غير مصرح'}), 403
    qty   = float(b.get('qty',   row['qty']))
    price = float(b.get('price', row['price']))
    total = round(qty * price, 2)
    c.execute(
        f"""UPDATE orders SET client={PH},fuel_type={PH},qty={PH},price={PH},
            total={PH},status={PH},notes={PH} WHERE id={PH}""",
        (b.get('client', row['client']), b.get('fuel_type', row['fuel_type']),
         qty, price, total, b.get('status', row['status']),
         b.get('notes', row['notes']), oid)
    )
    conn.commit(); conn.close()
    return jsonify({'ok': True})

@app.route('/api/orders/<int:oid>', methods=['DELETE'])
def delete_order(oid):
    user, err, code = require_auth()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    c.execute(f"SELECT * FROM orders WHERE id={PH}", (oid,))
    row = fetchone(c)
    if not row:
        conn.close()
        return jsonify({'ok': False, 'error': 'الطلب غير موجود'}), 404
    if user['role'] != 'admin' and row['owner_id'] != user['id']:
        conn.close()
        return jsonify({'ok': False, 'error': 'غير مصرح'}), 403
    c.execute(f"DELETE FROM orders WHERE id={PH}", (oid,))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


# ──────────────────────────────────────────────
#  API: العملاء
# ──────────────────────────────────────────────
@app.route('/api/clients', methods=['GET'])
def get_clients():
    user, err, code = require_auth()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    c.execute("SELECT * FROM clients ORDER BY name")
    rows = fetchall(c); conn.close()
    return jsonify({'ok': True, 'clients': rows})

@app.route('/api/clients', methods=['POST'])
def create_client():
    user, err, code = require_auth()
    if err: return err, code
    b = request.get_json() or {}
    conn = get_db(); c = conn.cursor()
    try:
        c.execute(
            f"INSERT INTO clients (name,phone,location) VALUES ({PH},{PH},{PH})",
            (b.get('name'), b.get('phone', ''), b.get('location', ''))
        )
        conn.commit()
        return jsonify({'ok': True})
    except Exception:
        return jsonify({'ok': False, 'error': 'العميل موجود مسبقاً'})
    finally:
        conn.close()

@app.route('/api/clients/<int:cid>', methods=['PUT'])
def update_client(cid):
    user, err, code = require_auth()
    if err: return err, code
    b = request.get_json() or {}
    conn = get_db(); c = conn.cursor()
    c.execute(
        f"UPDATE clients SET name={PH},phone={PH},location={PH} WHERE id={PH}",
        (b.get('name'), b.get('phone', ''), b.get('location', ''), cid)
    )
    conn.commit(); conn.close()
    return jsonify({'ok': True})

@app.route('/api/clients/<int:cid>', methods=['DELETE'])
def delete_client(cid):
    user, err, code = require_auth()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    c.execute(f"DELETE FROM clients WHERE id={PH}", (cid,))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


# ──────────────────────────────────────────────
#  API: المستخدمون
# ──────────────────────────────────────────────
@app.route('/api/users', methods=['GET'])
def get_users():
    user, err, code = require_admin()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    c.execute("SELECT id,username,fullname,role,active,created_at FROM users ORDER BY id")
    rows = fetchall(c); conn.close()
    return jsonify({'ok': True, 'users': rows})

@app.route('/api/users', methods=['POST'])
def create_user():
    user, err, code = require_admin()
    if err: return err, code
    b = request.get_json() or {}
    conn = get_db(); c = conn.cursor()
    try:
        c.execute(
            f"INSERT INTO users (username,password,fullname,role) VALUES ({PH},{PH},{PH},{PH})",
            (b.get('username'), hash_pw(b.get('password', '')),
             b.get('fullname', b.get('username')), b.get('role', 'user'))
        )
        conn.commit()
        return jsonify({'ok': True})
    except Exception:
        return jsonify({'ok': False, 'error': 'اسم المستخدم موجود مسبقاً'})
    finally:
        conn.close()

@app.route('/api/users/<int:uid>', methods=['PUT'])
def update_user(uid):
    user, err, code = require_admin()
    if err: return err, code
    b = request.get_json() or {}
    conn = get_db(); c = conn.cursor()
    if 'password' in b:
        c.execute(f"UPDATE users SET password={PH} WHERE id={PH}", (hash_pw(b['password']), uid))
    if 'active' in b:
        c.execute(f"UPDATE users SET active={PH} WHERE id={PH}", (1 if b['active'] else 0, uid))
    if 'role' in b:
        c.execute(f"UPDATE users SET role={PH} WHERE id={PH}", (b['role'], uid))
    if 'fullname' in b:
        c.execute(f"UPDATE users SET fullname={PH} WHERE id={PH}", (b['fullname'], uid))
    conn.commit(); conn.close()
    return jsonify({'ok': True})

@app.route('/api/users/<int:uid>', methods=['DELETE'])
def delete_user(uid):
    user, err, code = require_admin()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    c.execute(f"SELECT role FROM users WHERE id={PH}", (uid,))
    row = fetchone(c)
    if row and row['role'] == 'admin':
        conn.close()
        return jsonify({'ok': False, 'error': 'لا يمكن حذف المسؤول'})
    c.execute(f"DELETE FROM users WHERE id={PH}", (uid,))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


# ──────────────────────────────────────────────
#  API: الإحصائيات
# ──────────────────────────────────────────────
@app.route('/api/stats')
def get_stats():
    user, err, code = require_auth()
    if err: return err, code
    conn = get_db(); c = conn.cursor()
    if user['role'] == 'admin':
        c.execute("SELECT * FROM orders")
    else:
        c.execute(f"SELECT * FROM orders WHERE owner_id={PH}", (user['id'],))
    rows = fetchall(c); conn.close()
    stats = {
        'total':   len(rows),
        'diesel':  sum(r['qty'] for r in rows if r['fuel_type'] == 'ديزل'),
        'petrol':  sum(r['qty'] for r in rows if r['fuel_type'] == 'بنزين 91'),
        'revenue': sum(r['total'] for r in rows if r['status'] == 'مكتمل'),
        'pending': sum(1 for r in rows if r['status'] == 'معلق'),
    }
    return jsonify({'ok': True, 'stats': stats})


# ──────────────────────────────────────────────
#  تشغيل
# ──────────────────────────────────────────────
if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 8765))
    print(f"""
╔══════════════════════════════════════════╗
║     FuelTrack Server — قيد التشغيل      ║
╠══════════════════════════════════════════╣
║  الرابط:  http://localhost:{port}           ║
║  قاعدة البيانات: {DB_TYPE:<24}║
╠══════════════════════════════════════════╣
║  المستخدمون الافتراضيون:                ║
║  admin    → admin123  (مسؤول)           ║
║  user1-10 → user1234  (مستخدم)          ║
╚══════════════════════════════════════════╝
""")
    app.run(host='0.0.0.0', port=port, debug=False)
